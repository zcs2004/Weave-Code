/* WeaveCode / 织码 — minimal page interactions */
"use strict";

const languageButton = document.getElementById("language-switch");
const tagline = document.getElementById("tagline");

let isEnglish = false;

const taglineText = {
  zh: '以代码为线，<span>编织数字世界。</span>',
  en: 'Code is the thread,<span> weaving the digital world.</span>'
};

function setLanguage(useEnglish) {
  isEnglish = useEnglish;
  document.documentElement.lang = isEnglish ? "en" : "zh-CN";
  languageButton.textContent = isEnglish ? "中文 / EN" : "EN / 中文";
  languageButton.setAttribute("aria-pressed", String(isEnglish));
  tagline.innerHTML = taglineText[isEnglish ? "en" : "zh"];

  document.querySelectorAll("[data-zh][data-en]").forEach((element) => {
    element.textContent = isEnglish ? element.dataset.en : element.dataset.zh;
  });

  document.title = isEnglish
    ? "WeaveCode — Weave the Digital World"
    : "织码 WeaveCode — 编织数字世界";
}

languageButton.addEventListener("click", () => {
  setLanguage(!isEnglish);
});

// Start in Chinese by default.
setLanguage(false);
